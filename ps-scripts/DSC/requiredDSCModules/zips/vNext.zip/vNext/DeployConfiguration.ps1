﻿$ConfigData = @{
AllNodes = @()
}